package WorkClass;

import CommandWorker.Command;
import Reader.CommandLine;
import SetItems.LabWork;

public class AddIfMax implements Command {
    private LabWork newLab;
    private CommandLine commandLine;
    public AddIfMax(CommandLine commandLine){
        this.commandLine = commandLine;
    }
    @Override
    public void execute() {
        newLab = commandLine.getCreationLabwork().creationLabwork();
        if (commandLine.findMaxMinimalPoint() < newLab.getMinimalPoint()){
            commandLine.insert(newLab);
            commandLine.sortCollection();
            System.out.println("Лабораторная работа " + newLab.getName() + " добавлена! ");
        } else System.out.println("Лабораторная работа " + newLab.getName() + " не добавлена!");
    }
}
