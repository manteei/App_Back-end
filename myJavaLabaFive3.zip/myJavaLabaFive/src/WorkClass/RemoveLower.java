package WorkClass;

import CommandWorker.Command;
import Reader.CommandLine;
import SetItems.LabWork;

public class RemoveLower implements Command {
    private LabWork newLab;
    private CommandLine commandLine;
    public RemoveLower(CommandLine commandLine){
        this.commandLine = commandLine;
    }
    @Override
    public void execute(){
        newLab = commandLine.getCreationLabwork().creationLabwork();
        commandLine.removeLower(newLab);
    }
}
