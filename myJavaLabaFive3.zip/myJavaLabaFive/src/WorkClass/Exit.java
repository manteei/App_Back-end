package WorkClass;

import CommandWorker.Command;

public class Exit implements Command {
    @Override
    public void execute() {
        System.out.println("Программа завершена!");
        System.exit(0);
    }
}
