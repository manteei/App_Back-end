package WorkClass;

import CommandWorker.CommandWithArgument;
import Reader.CommandLine;
import Reader.LineReader;

public class Update implements CommandWithArgument {
    private String[] arguments;
    private CommandLine commandLine;
    private LineReader lineReader;

    public Update(CommandLine commandLine, LineReader lineReader){
        this.commandLine = commandLine;
        this.lineReader = lineReader;
    }
    @Override
    public void execute() {
       try {
           int oldId = Integer.parseInt(arguments[0]);
           if (commandLine.containsCollection(oldId)) {
               commandLine.removeId(oldId);
               commandLine.insert(commandLine.getCreationLabwork().updateLabwork(oldId));
               commandLine.sortCollection();
           } else {
               System.err.println("Нет элемента с таким id!\n");
           }
       } catch (ArrayIndexOutOfBoundsException e){
           System.err.println("Не указан аргумент команды!\n");
       }
    }

    @Override
    public void getArgument(String[] arguments) {
        this.arguments = arguments;
    }
}
