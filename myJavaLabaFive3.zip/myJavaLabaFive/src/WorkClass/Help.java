package WorkClass;

import CommandWorker.Command;
import Reader.CommandLine;

public class Help implements Command {
    private CommandLine commandLine;
    public Help(CommandLine commandLine){
        this.commandLine = commandLine;
    }
    @Override
    public void execute(){
        commandLine.help();
    }
}
