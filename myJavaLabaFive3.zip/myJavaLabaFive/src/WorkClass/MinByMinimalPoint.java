package WorkClass;

import CommandWorker.Command;
import Reader.CommandLine;

public class MinByMinimalPoint implements Command {
    private CommandLine commandLine;
    public MinByMinimalPoint(CommandLine commandLine){
        this.commandLine = commandLine;
    }
    @Override
    public void execute() {
        commandLine.labMinimalPoint();
    }
}
