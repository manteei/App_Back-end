package WorkClass;

import CommandWorker.Command;
import Reader.CommandLine;

public class Add implements Command {
   private CommandLine commandLine;
   public Add(CommandLine commandLine){
       this.commandLine = commandLine;
   }
    @Override
    public void execute() {
        commandLine.insert(commandLine.getCreationLabwork().creationLabwork());
        commandLine.sortCollection();
    }
}
