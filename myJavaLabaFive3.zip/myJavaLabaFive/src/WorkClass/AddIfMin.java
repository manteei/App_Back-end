package WorkClass;

import CommandWorker.Command;
import Reader.CommandLine;
import SetItems.LabWork;

public class AddIfMin implements Command {
    private LabWork newLab;
    private CommandLine commandLine;
    public AddIfMin(CommandLine commandLine){
        this.commandLine = commandLine;
    }
    @Override
    public void execute() {
        newLab = commandLine.getCreationLabwork().creationLabwork();
        if (commandLine.findMinimalWeight() > newLab.getAuthor().getWeight()){
            commandLine.insert(newLab);
            commandLine.sortCollection();
            System.out.println("Лабораторная работа " + newLab.getName() + " добавлена! ");
        } else System.out.println("Лабораторная работа " + newLab.getName() + " не добавлена!");
    }
}
