package WorkClass;

import CommandWorker.Command;
import Reader.CommandLine;

public class Info implements Command {
    private CommandLine commandLine;
    public Info(CommandLine commandLine){
        this.commandLine = commandLine;
    }
    @Override
    public void execute() {
        commandLine.info();
    }


}
