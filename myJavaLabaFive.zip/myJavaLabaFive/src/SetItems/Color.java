package SetItems;

public enum Color {
    GREEN("green"),
    YELLOW("yellow"),
    WHITE("white"),
    BROWN("brown");
    String color;
    Color(String color){
        this.color = color;
    }
}
