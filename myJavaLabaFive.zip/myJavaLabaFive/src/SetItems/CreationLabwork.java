package SetItems;

import Reader.FillerFields;
import Reader.LineReader;
import Reader.CommandLine;

import java.time.LocalDateTime;
import java.util.Scanner;

public class CreationLabwork {
    private int id = 1;
    private int newId = 1;
    Scanner scanner = new Scanner(System.in);
    private LineReader lineReader = new LineReader(scanner);
    private FillerFields fillerFields = new FillerFields();

    public LabWork CreationLabwork(){
        return new LabWork(getId(), fillerFields.readName(), fillerFields.readCoordinates(), LocalDateTime.now(), fillerFields.readMinimalPoint(), fillerFields.readDifficulty(), fillerFields.readPerson());
    }

    public int getId() {
        return id++;
    }

    public void setId(int id) {
        this.id = id;
    }
    public int getNewId(CommandLine commandLine){
        int newId = 1;
        for(LabWork lab: commandLine.getLabworks()){
            if (newId != lab.getId()){
                return newId;
            } newId++;
        }
        return newId;
    }
}
