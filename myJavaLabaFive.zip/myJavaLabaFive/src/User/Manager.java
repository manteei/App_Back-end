package User;

import CommandWorker.Commander;
import Reader.CommandLine;
import Reader.FillerFields;
import Reader.LineReader;
import Reader.XmlParser;
import SetItems.CreationLabwork;

import java.io.File;
import java.io.IOException;
import java.util.NoSuchElementException;

public class Manager {
    CommandLine commandLine;
    XmlParser xmlParser;
    LineReader lineReader;
    Commander commander;
    FillerFields fillerFields;
    public void start(String xmlfile) {
        commandLine = new CommandLine();
        xmlParser = new XmlParser(commandLine , commandLine.getCreationLabwork());
        lineReader = new LineReader();
        this.commander = new Commander(commandLine, lineReader, xmlfile, fillerFields);

        try {
            File file = new File(xmlfile);
            if (!file.canWrite() || !file.isFile() || file.isDirectory()) throw new IOException();
            xmlParser.fromXmlToObject();
            if (commandLine.getSize()==0){
                System.out.println("Добавьте объекты с помощью команды add, после чего введите команды save для сохранения в xml!");
            } else System.out.println("Объекты из файла загружены!");

        } catch (IOException e) {
            System.out.println("Такого файла нет!");
            System.exit(0);
        }

        try{
            process();
        } catch (NoSuchElementException e){
            System.out.println(e.getMessage());
        }

    }

    public void process(){
        System.out.println("Программа запущена");
        while (true){
            System.out.println("\nВведите название команды");
            String command = lineReader.getLine();
            commander.execute(command);
        }
    }


}
