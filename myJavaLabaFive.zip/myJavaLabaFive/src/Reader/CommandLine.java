package Reader;

import SetItems.*;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayDeque;
import java.time.LocalDateTime;

@XmlRootElement(name = "labworks")
public class CommandLine {

    private ArrayDeque<LabWork> collection;
    private LocalDateTime date;
    private CreationLabwork creationLabwork;

    public CommandLine() {
        collection = new ArrayDeque<LabWork>();
        date = LocalDateTime.now();
        creationLabwork = new CreationLabwork();
    }
    @XmlElement(name = "labwork")
    public void setCollection(ArrayDeque<LabWork> list) {
        collection = list;
    }

    /**
     * Метод вывода информации о коллекции
     */
    public void info(){
        System.out.println("Тип коллекции: ArrayDeque");
        System.out.println("Дата и время инициализации: " + date);
        System.out.println("Kоличество элементов: " + collection.size());
    }
    /**
     * Метод вывода всех элементов коллекции
     */
    public ArrayDeque<LabWork> getLabworks(){
        return collection;
    }

    public void insert(LabWork labWork){
        int id2 = labWork.getId();
        boolean stock = false;
        for (LabWork lab: getLabworks()){
            if (containsCollection(id2)){
                ++id2;
            }
            labWork.setId(id2);
            collection.add(labWork);
            creationLabwork.setId(id2++);
        }
    }
    //Есть ли элемент с данным id в коллекции
    public boolean containsCollection(int id){
        for (LabWork lab: this.getLabworks()){
            if(lab.getId() == id){
                return true;
            }
        }
        return false;
    }
    public boolean removeId(int id){
        for (LabWork lab: collection){
            if(lab.getId() == id){
                collection.remove(lab);
                creationLabwork.setId(creationLabwork.getNewId(this));
                return true;
            }
        }
        return false;
    }
    public CreationLabwork getCreationLabwork(){
        return creationLabwork;
    }
    public int getSize(){
        return collection.size();
    }

}
