package Reader;

import SetItems.*;
import java.util.Locale;
import java.util.Scanner;

public class FillerFields {
    Scanner scanner = new Scanner(System.in);
    private LineReader lineReader = new LineReader(scanner);

    public String readName(){
        String line;
        while (true){
            lineReader.printEscortMessage("Введите название лабораторной работы (не может быть null и пустой строкой)");
            line = lineReader.getLine();
             if (line.trim().equals("null")){
                 lineReader.printErrorMessage("Ошибка: имя не может быть null!");
             }
             else if (line.trim().equals("")){
                 lineReader.printErrorMessage("Ошибка: имя не может быть пустой строкой!");
             } else {
             return line;
            }
        }
    }
    public long readX(){
        String line;
        while (true) {
            try {
                lineReader.printEscortMessage("Введите координату X");
                line = lineReader.getLine();
                if (line.trim().equals("")) {
                    lineReader.printErrorMessage("Ошибка: координата Х не может быть пустой строкой!");
                }
                return Long.parseLong(line.trim());
            } catch (NumberFormatException e){
                lineReader.printErrorMessage("Ошибка: координата Х должна быть задана числом");
            }
        }
    }
    public long readY(){
        String line;
        long y;
        while (true) {
            try {
                lineReader.printEscortMessage("Введите координату Y (Должно быть больше -732)");
                line = lineReader.getLine();
                if (line.trim().equals("")) {
                    lineReader.printErrorMessage("Ошибка: координата Y не может быть пустой строкой!");
                }
                y = Long.parseLong(line.trim());
                if (y <= -732){
                    throw new IllegalArgumentException();
                }
            } catch (NumberFormatException e){
                lineReader.printErrorMessage("Ошибка: координата Y должна быть задана числом");
            } catch (IllegalArgumentException e1){
                lineReader.printErrorMessage("Ошибка: координата Y должна быть задана числом больше -732");
            }
        }
    }
    public Coordinates readCoordinates(){
        return new Coordinates(readX(), readY());
    }
    public Double readMinimalPoint(){
        String line;
        Double minimalPoint;
        while (true){
            try{
                lineReader.printEscortMessage("Введите минимальный балл(не может быть null и должно быть больше 0)");
                line = lineReader.getLine();
                if (line.trim().equals("")){
                    lineReader.printErrorMessage("Ошибка: минимальный балл не может быть пустой строкой!");
                }
                if (line.trim().equals("null")){
                    lineReader.printErrorMessage("Ошибка: минимальный балл не может быть null!");
                }
                minimalPoint = Double.parseDouble(line.trim());
                if (minimalPoint <= 0){
                    throw new IllegalArgumentException();
                }
                return minimalPoint;
            } catch (NumberFormatException e){
                lineReader.printErrorMessage("Ошибка: минимальный балл должен быть задан числом");
            } catch (IllegalArgumentException e1){
                lineReader.printErrorMessage("Ошибка: минимальный балл должен быть больше 0");
            }
        }

    }
    public Difficulty readDifficulty(){
        String line;
        Difficulty difficulty;
        lineReader.printEscortMessage("Выберите из списка и введите сложность лабораторной работы:");
        for (Difficulty diff: Difficulty.values()){
            System.out.println(diff.name());
        }
        while (true){
            try{
                line = lineReader.getLine();
                if (line.trim().equals("null")){
                    return null;
                } else {
                    difficulty = Difficulty.valueOf(line.trim().toUpperCase());
                    return difficulty;
                }

            } catch (IllegalArgumentException e){
                lineReader.printErrorMessage("Ошибка: такого варианта сложности нет!");
            }
        }

    }

    public String readAuthorName(){
        String line;
        while (true){
            lineReader.printEscortMessage("Введите имя автора лабораторной работы  работы (не может быть null и пустой строкой)");
            line = lineReader.getLine();
            if (line.trim().equals("null")){
                lineReader.printErrorMessage("Ошибка: имя не может быть null!");
            }
            else if (line.trim().equals("")){
                lineReader.printErrorMessage("Ошибка: имя не может быть пустой строкой!");
            } else {
                return line;
            }
        }
    }
    public Double readWeight(){
        String line;
        Double weight;
        while (true){
            try{
                lineReader.printEscortMessage("Введите вес (не может быть null и должно быть больше 0)");
                line = lineReader.getLine();
                if (line.trim().equals("")){
                    lineReader.printErrorMessage("Ошибка: вес не может быть пустой строкой!");
                }
                else if (line.trim().equals("null")){
                    lineReader.printErrorMessage("Ошибка: вес не может быть null!");
                }
                weight = Double.parseDouble(line.trim());
                if (weight <= 0){
                    throw new IllegalArgumentException();
                }
                return weight;
            } catch (NumberFormatException e){
                lineReader.printErrorMessage("Ошибка: вес должен быть задан числом!");
            } catch (IllegalArgumentException e1){
                lineReader.printErrorMessage("Ошибка: вес должен быть больше 0!");
            }
        }

    }
    public String readPassportId(){
        String line;
        while (true) {
            try {
                lineReader.printEscortMessage("Введите номер паспорта (Не больше 30 символов, не может быть null и пустой строкой)");
                line = lineReader.getLine();
                if (line.trim().equals("")) {
                    lineReader.printErrorMessage("Ошибка: номер паспорта не может быть пустой строкой!");
                } else if (line.trim().equals("null")) {
                    lineReader.printErrorMessage("Ошибка: номер паспорта не может быть null!");
                }
                else if (line.trim().length() >30){
                    throw new IllegalArgumentException();
                }
            } catch (IllegalArgumentException e){
                lineReader.printErrorMessage("Ошибка: номер паспорта не должен быть длиннее 30");
            }
        }
    }
    public Color readColor(){
        String line;
        Color color;
        lineReader.printEscortMessage("Выберите из списка и введите цвет волос автора работы:");
        for (Color col: Color.values()){
            System.out.println(col.name());
        }
        while (true){
            try{
                line = lineReader.getLine();
                if (line.trim().equals("null")){
                    lineReader.printErrorMessage("Ошибка: цвет волос не может быть null");
                } else {
                    color = Color.valueOf(line.trim().toUpperCase());
                    return color;
                }

            } catch (IllegalArgumentException e){
                lineReader.printErrorMessage("Ошибка: такого варианта цвета нет!");
            }
        }

    }
    public Country readNationality(){
        String line;
        Country country;
        lineReader.printEscortMessage("Выберите из списка и введите национальность автора работы:");
        for (Country con: Country.values()){
            System.out.println(con.name());
        }
        while (true){
            try{
                line = lineReader.getLine();
                if (line.trim().equals("null")){
                    lineReader.printErrorMessage("Ошибка: национальность не может быть null");
                } else {
                    country = Country.valueOf(line.trim().toUpperCase());
                    return country;
                }

            } catch (IllegalArgumentException e){
                lineReader.printErrorMessage("Ошибка: такого варианта национальности нет!");
            }
        }

    }
    public Person readPerson(){
        return new Person(readAuthorName(), readWeight(), readPassportId(),readColor(), readNationality());
    }

}
