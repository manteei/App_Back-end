package Reader;

import SetItems.Color;
import SetItems.Difficulty;
import SetItems.LabWork;

public class FileChecker {
    private CommandLine commandLine;

    public FileChecker(CommandLine commandLine){
        this.commandLine = commandLine;
    }

    public boolean chekId(LabWork labWork){
        if (labWork.getId() <= 0 ){
            System.out.println("Ошибка: id должно быть больше 0!");
            return false;
        }return true;
    }
    public boolean chekName(LabWork labWork){
        if (labWork.getName().equals("null")){
            System.out.println("Ошибка: имя не может быть null!");
            return false;
        } if(labWork.getName().equals("")){
            System.out.println("Ошибка: имя не может быть пустым!");
            return false;
        } return true;

    }
    public boolean chekCoordinates(LabWork labWork){
        try {
            if (String.valueOf(labWork.getCoordinates().getX()).equals("null")) {
                System.out.println("Ошибка: координата Х не может быть null!");
                return false;
            }
            if (String.valueOf(labWork.getCoordinates().getY()).equals("null")) {
                System.out.println("Ошибка: координата Y не может быть null!");
                return false;
            } else if (labWork.getCoordinates().getY() <= -732) {
                System.out.println("Ошибка: координата Y должна быть больше -732!");
                return false;
            }
        } catch (NullPointerException e){
            System.out.println("Ошибка: координаты заданы некорректно!");
            return false;
        }
        return true;
    }
    public boolean checkMinimalPoint(LabWork labWork){
            if (String.valueOf(labWork.getMinimalPoint()).equals("null")){
                System.out.println("Ошибка: минимальная оценка не может быть null! ");
                return false;
            } else if(labWork.getMinimalPoint()<=0){
                System.out.println("Ошибка: минимальная оценка должна быть больше 0! ");
                return false;
            }
            return true;
    }
    public boolean checkDifficulty(LabWork labWork){
        try {
             Difficulty.valueOf(String.valueOf(labWork.getDifficulty()).toUpperCase());
        } catch (IllegalArgumentException e){
            return false;
        }
        return true;
    }
    public boolean checkPerson(LabWork labWork){
        try {
            Color.valueOf(String.valueOf(labWork.getAuthor().getHairColor()).toUpperCase());
            if (String.valueOf(labWork.getAuthor().getName()).equals("null")){
                System.out.println("Ошибка: имя автора не может быть null! ");
                return false;
            }if (String.valueOf(labWork.getAuthor().getName()).equals("")){
                System.out.println("Ошибка: имя автора не может быть пустой строкой! ");
                return false;
            }if (String.valueOf(labWork.getAuthor().getWeight()).equals("null")){
                System.out.println("Ошибка: вес не может быть null! ");
                return false;
            } else if (labWork.getAuthor().getWeight()<=0){
                System.out.println("Ошибка: вес должен быть больше 0! ");
                return false;
            }if (String.valueOf(labWork.getAuthor().getPassportID()).equals("null")){
                System.out.println("Ошибка: номер паспорта не может быть null! ");
                return false;
            }if (String.valueOf(labWork.getAuthor().getPassportID()).equals("")){
                System.out.println("Ошибка: номер паспорта не может быть пустой строкой! ");
                return false;
            }if (String.valueOf(labWork.getAuthor().getPassportID()).length() > 30){
                System.out.println("Ошибка: длина номера паспорта не должна быть больше 30! ");
                return false;
            }if (String.valueOf(labWork.getAuthor().getHairColor()).equals("null")){
                System.out.println("Ошибка: цвет волос автора не может быть null! ");
                return false;
            }if (String.valueOf(labWork.getAuthor().getNationality()).equals("null")) {
                System.out.println("Ошибка: цвет волос автора не может быть null! ");
                return false;
            }

        }catch (IllegalArgumentException e){
            System.out.println("Ошибка: некорректный цвет волос автора!");
        }
        return true;
    }
    public boolean IdStock(LabWork labWork){
        for(LabWork lab : commandLine.getLabworks()){
            if(lab.getId() == labWork.getId()){
                commandLine.removeId(lab.getId());
                return true;
            }
        } return false;
    }

}
