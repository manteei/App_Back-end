package CommandWorker;

import Reader.CommandLine;

public class Show implements Command {
    private CommandLine commandLine;
    public Show(CommandLine commandLine) {
        this.commandLine = commandLine;
    }


    @Override
    public void execute() {

    }
}
