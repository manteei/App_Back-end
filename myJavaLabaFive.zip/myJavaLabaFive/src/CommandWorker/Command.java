package CommandWorker;

public interface Command {
    void execute();
}
