package CommandWorker;

import Reader.FillerFields;
import Reader.LineReader;
import Reader.CommandLine;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class ExecuteScript implements CommandWithArgument{
    private String[] commandArgument;
    private CommandLine commandLine;
    private FillerFields fillerFields;
    private LineReader lineReader;
    private Script script;
    private String scriptPath;
    public ExecuteScript(CommandLine commandLine, FillerFields fillerFields, Script script){
        this.commandLine = commandLine;
        this.fillerFields = fillerFields;
        this.script = script;
    }
    @Override
    public void execute(){
        try {
            if (commandArgument.length == 1) {
                scriptPath = commandArgument[0];
                if (script.scriptPath.contains(scriptPath)) {
                    System.err.println("Попытка рекурсивного вызова скрипта внутри него же!");
                    return;
                }
                else script.putScript(scriptPath);
            } else throw new IllegalArgumentException();
            File ioFile = new File(scriptPath);
            if (!ioFile.canWrite() || ioFile.isDirectory() || !ioFile.isFile()) throw new IOException();
            FileInputStream fileInputStream = new FileInputStream(scriptPath);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            Scanner scanner = new Scanner(inputStreamReader);
            lineReader = new LineReader(scanner);
            Commander commander = new Commander(commandLine, script, lineReader, fillerFields);
            while (scanner.hasNext()) {
                commander.execute(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.err.println("Файл скрипта не найден!");
        } catch (IOException e2) {
            System.err.println("Нет доступа к файлу" + e2.getMessage());
        } catch (IllegalArgumentException e3) {
            System.err.println("Скрипт не передан в качестве аргумента команды , либо кол-во аргументов больше 1!");
        } catch (NullPointerException e5) {
            System.err.println("Не выбран файл, из которого читать скрипт!");
        }

    }

    @Override
    public void getArgument(String[] arguments) {
        this.commandArgument = arguments;
    }

    static class Script{

        private ArrayList<String> scriptPath = new ArrayList<>();

        public void putScript(String path){
            scriptPath.add(path);
        }
        public void removeScript(String path){
            scriptPath.remove(path);
        }
    }

}
