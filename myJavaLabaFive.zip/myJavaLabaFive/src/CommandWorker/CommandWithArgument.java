package CommandWorker;

public interface CommandWithArgument extends Command{
    void getArgument(String[] arguments);
}
